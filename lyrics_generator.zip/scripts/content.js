const insert = (content) => {
	// Find Calmly editor input section
	/*
	const elements = document.getElementsByClassName('droid');
	
	if (elements.length === 0) {
	  return;
	}

	const element = elements[0];

	// Grab the first p tag so we can replace it with our injection
	const pToRemove = element.childNodes[0];
	pToRemove.remove();
*/
	// Split content by \n
	const splitContent = content.split('\n');

	
	// Wrap in p tags
	splitContent.forEach((content) => {
	  const p = document.createElement('p');

	  if (content === '') {
		const br = document.createElement('br');
		p.appendChild(br);
	  } else {
		p.textContent = content;
	  }

	   	console.log('content : ' + content);
	   //newContent = content + '<BR>';
	   
      // Insert into HTML one at a time
	//  element.appendChild(p);
	});

	var win;
	if (content != 'generating...'){
		win = window.open("", "Result", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=780,height=500");
		splitContent.forEach((content) => {
			win.document.body.innerHTML += content + '<BR>';
		});
	}
	
  // On success return true
  return true;
};

chrome.runtime.onMessage.addListener(
  // This is the message listener
  (request, sender, sendResponse) => {
    if (request.message === 'inject') {
      const { content } = request;
			
      // Call this insert function
      const result = insert(content);

	  console.log(content);	
      
	  // If something went wrong, send a failed status
      if (!result) {
        sendResponse({ status: 'failed' });
      }

      sendResponse({ status: 'success' });
	  
    }
  }
);

